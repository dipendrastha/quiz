# CTF Challenge — GraphQL Nested Query

A small social posting web app with a hidden vulnerability.

## Stack

- **Frontend:** React + Vite (served as static files)
- **Backend:** Node.js (no framework) + GraphQL + SQLite

## Setup

### Requirements

- Node.js 18+

### Backend

```bash
cd backend
npm install
node server.js
```

Runs on `http://localhost:4000`. Database is created and seeded automatically on first run.

### Frontend

Build once and serve the static files:

```bash
cd frontend
npm install
npm run build
```

Then serve `frontend/dist/` with any static file server, e.g.:

```bash
npx serve frontend/dist
```

Or for development:

```bash
cd frontend
npm run dev
```

Runs on `http://localhost:5173`.

### Environment Variables

| Variable     | Default                | Description          |
|--------------|------------------------|----------------------|
| `JWT_SECRET` | `ctf_jwt_secret_key`   | Secret for JWT signing |
| `PORT`       | `4000`                 | Backend port         |

Create a `.env` file in `backend/` to override:

```
JWT_SECRET=change_this_in_production
PORT=4000
```

## Reset Challenge

Click the **Purge DB** button in the app UI, or call the mutation directly:

```bash
curl -X POST http://localhost:4000/graphql \
  -H "Content-Type: application/json" \
  -d '{"query":"mutation { purgeDatabase }"}'
```

This wipes all users and posts and re-seeds the original data.
