import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  build: {
    minify: true,
    sourcemap: false,
  },
  server: {
    proxy: {
      '/graphql': 'http://localhost:4000',
    },
  },
})
