import { useState, useEffect, useCallback } from 'react';
import { gql } from './api';

// ── Design tokens (mirrors CSS vars for inline styles) ────────────────────────
const C = {
  bg:      '#0d1117',
  bg2:     '#161b22',
  bg3:     '#1c2128',
  border:  '#30363d',
  accent:  '#00d4aa',
  accent2: '#58a6ff',
  danger:  '#f85149',
  text:    '#e6edf3',
  text2:   '#8b949e',
  text3:   '#6e7681',
};

// ── Helpers ───────────────────────────────────────────────────────────────────

function Avatar({ name, size = 36 }) {
  const initials = (name || '?').slice(0, 2).toUpperCase();
  const hue = [...(name || '')].reduce((n, c) => n + c.charCodeAt(0), 0) % 360;
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%',
      background: `hsl(${hue},55%,28%)`,
      border: `2px solid hsl(${hue},55%,42%)`,
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: size * 0.38, fontWeight: 700, color: `hsl(${hue},80%,80%)`,
      flexShrink: 0, userSelect: 'none', fontFamily: 'var(--mono)',
    }}>
      {initials}
    </div>
  );
}

function Badge({ children, color = C.accent }) {
  return (
    <span style={{
      background: `${color}22`, color, border: `1px solid ${color}44`,
      borderRadius: 4, fontSize: 11, padding: '1px 7px', fontFamily: 'var(--mono)',
      fontWeight: 600, letterSpacing: '0.03em',
    }}>
      {children}
    </span>
  );
}

function timeAgo(dateStr) {
  const diff = (Date.now() - new Date(dateStr)) / 1000;
  if (diff < 60) return 'just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// ── Auth ──────────────────────────────────────────────────────────────────────

function AuthForm({ onAuth }) {
  const [mode, setMode]         = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError]       = useState('');
  const [loading, setLoading]   = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const mutation = mode === 'login'
        ? 'mutation Login($u:String!,$p:String!){ login(username:$u,password:$p){ token user{id username bio} } }'
        : 'mutation Reg($u:String!,$p:String!){ register(username:$u,password:$p){ token user{id username bio} } }';
      const data = await gql(mutation, { u: username, p: password });
      const payload = mode === 'login' ? data.login : data.register;
      onAuth(payload.token, payload.user);
    } catch (err) {
      setError(err.message);
    } finally { setLoading(false); }
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: C.bg, padding: 16,
    }}>
      {/* Left panel — branding */}
      <div style={{ display: 'flex', gap: 48, alignItems: 'center', maxWidth: 860, width: '100%' }}>
        <div style={{ flex: 1, display: 'none' }} className="auth-brand" />

        {/* Card */}
        <div style={{
          flex: '0 0 360px', background: C.bg2, border: `1px solid ${C.border}`,
          borderRadius: 12, padding: '36px 32px',
        }}>
          {/* Logo */}
          <div style={{ marginBottom: 28, textAlign: 'center' }}>
            <div style={{
              display: 'inline-flex', alignItems: 'center', gap: 10,
              background: `${C.accent}15`, border: `1px solid ${C.accent}33`,
              borderRadius: 8, padding: '8px 16px',
            }}>
              <span style={{ fontSize: 20 }}>⚡</span>
              <span style={{ fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 18, color: C.accent }}>
                NexusNet
              </span>
            </div>
            <p style={{ color: C.text2, fontSize: 12, marginTop: 8, fontFamily: 'var(--mono)' }}>
              SOCIAL · SECURE · CONNECTED
            </p>
          </div>

          <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 20, color: C.text }}>
            {mode === 'login' ? 'Sign in to your account' : 'Create an account'}
          </h2>

          <form onSubmit={handleSubmit}>
            <div style={{ marginBottom: 14 }}>
              <label style={{ display: 'block', fontSize: 12, color: C.text2, marginBottom: 5, fontWeight: 500 }}>
                Username
              </label>
              <input
                placeholder="Enter your username"
                value={username}
                onChange={e => setUsername(e.target.value)}
                required
                autoComplete="username"
              />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ display: 'block', fontSize: 12, color: C.text2, marginBottom: 5, fontWeight: 500 }}>
                Password
              </label>
              <input
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                required
                autoComplete="current-password"
              />
            </div>

            {error && (
              <div style={{
                background: `${C.danger}15`, border: `1px solid ${C.danger}44`,
                borderRadius: 6, padding: '8px 12px', marginBottom: 14,
                color: C.danger, fontSize: 13,
              }}>
                {error}
              </div>
            )}

            <button
              type="submit"
              className="btn-primary"
              disabled={loading}
              style={{ width: '100%', padding: '10px', fontSize: 14 }}
            >
              {loading ? '…' : mode === 'login' ? 'Sign In' : 'Create Account'}
            </button>
          </form>

          <div style={{
            borderTop: `1px solid ${C.border}`, marginTop: 20, paddingTop: 16,
            textAlign: 'center',
          }}>
            <span style={{ color: C.text2, fontSize: 13 }}>
              {mode === 'login' ? "Don't have an account? " : 'Already have an account? '}
            </span>
            <button
              className="btn-ghost"
              style={{ fontSize: 13, padding: '2px 6px', color: C.accent }}
              onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setError(''); }}
            >
              {mode === 'login' ? 'Sign up' : 'Sign in'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// ── Top navbar ────────────────────────────────────────────────────────────────

const NAV_ITEMS = [
  { id: 'posts',    label: 'Feed',     icon: '⊞' },
  { id: 'users',    label: 'People',   icon: '◎' },
  { id: 'messages', label: 'Messages', icon: '✉' },
];

function Topbar({ user, view, onView, onLogout, onPurge }) {
  return (
    <header style={{
      position: 'sticky', top: 0, zIndex: 100,
      background: C.bg2, borderBottom: `1px solid ${C.border}`,
      display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 24px', height: 56,
    }}>
      {/* Brand */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: 18 }}>⚡</span>
        <span style={{
          fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 16, color: C.accent,
          letterSpacing: '-0.02em',
        }}>
          NexusNet
        </span>
        <Badge color={C.accent2}>CTF</Badge>
      </div>

      {/* Nav tabs */}
      <nav style={{ display: 'flex', gap: 4 }}>
        {NAV_ITEMS.map(item => (
          <button
            key={item.id}
            onClick={() => onView(item.id)}
            className="btn-ghost"
            style={{
              display: 'flex', alignItems: 'center', gap: 6,
              padding: '6px 14px', borderRadius: 6, fontSize: 13, fontWeight: 500,
              color: view === item.id ? C.accent : C.text2,
              background: view === item.id ? `${C.accent}15` : 'transparent',
              borderBottom: view === item.id ? `2px solid ${C.accent}` : '2px solid transparent',
              borderRadius: 0,
            }}
          >
            <span style={{ fontSize: 15 }}>{item.icon}</span>
            {item.label}
          </button>
        ))}
      </nav>

      {/* User actions */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <Avatar name={user.username} size={30} />
        <span style={{ fontSize: 13, color: C.text2 }}>
          <span style={{ color: C.text, fontWeight: 600 }}>{user.username}</span>
        </span>
        <button
          className="btn-danger btn-sm"
          onClick={onPurge}
          title="Reset challenge database"
        >
          ⟳ Reset DB
        </button>
        <button className="btn-secondary btn-sm" onClick={onLogout}>Sign out</button>
      </div>
    </header>
  );
}

// ── Layout wrapper ────────────────────────────────────────────────────────────

function PageLayout({ children }) {
  return (
    <main style={{
      maxWidth: 680, margin: '0 auto', padding: '24px 16px',
    }}>
      {children}
    </main>
  );
}

// ── Card ──────────────────────────────────────────────────────────────────────

function Card({ children, style = {} }) {
  return (
    <div style={{
      background: C.bg2, border: `1px solid ${C.border}`,
      borderRadius: 12, padding: '16px 20px', marginBottom: 14,
      ...style,
    }}>
      {children}
    </div>
  );
}

// ── Posts ─────────────────────────────────────────────────────────────────────

function CommentSection({ postId, initialComments }) {
  const [comments, setComments] = useState(initialComments || []);
  const [text, setText]         = useState('');
  const [open, setOpen]         = useState(false);
  const [err, setErr]           = useState('');

  async function submit(e) {
    e.preventDefault();
    setErr('');
    try {
      const data = await gql(
        'mutation($pid:ID!,$c:String!){ addComment(postId:$pid,content:$c){ id content createdAt author{username} } }',
        { pid: postId, c: text }
      );
      setComments(prev => [...prev, data.addComment]);
      setText('');
    } catch (e) { setErr(e.message); }
  }

  return (
    <div style={{ marginTop: 12, borderTop: `1px solid ${C.border}`, paddingTop: 12 }}>
      <button
        className="btn-ghost btn-sm"
        onClick={() => setOpen(o => !o)}
        style={{ color: C.text2, fontSize: 12 }}
      >
        {open ? '▲ Hide comments' : `💬 ${comments.length} comment${comments.length !== 1 ? 's' : ''}`}
      </button>

      {open && (
        <div style={{ marginTop: 12 }}>
          {comments.length === 0
            ? <p style={{ color: C.text3, fontSize: 13, marginBottom: 10 }}>No comments yet.</p>
            : comments.map(c => (
              <div key={c.id} style={{
                display: 'flex', gap: 10, marginBottom: 10,
              }}>
                <Avatar name={c.author.username} size={28} />
                <div style={{
                  background: C.bg3, borderRadius: 8, padding: '7px 12px', flex: 1,
                  border: `1px solid ${C.border}`,
                }}>
                  <span style={{ fontWeight: 600, fontSize: 13, color: C.accent2 }}>
                    {c.author.username}
                  </span>
                  <p style={{ margin: '3px 0 0', fontSize: 13, color: C.text }}>{c.content}</p>
                </div>
              </div>
            ))
          }

          <form onSubmit={submit} style={{ display: 'flex', gap: 8, marginTop: 6 }}>
            <input
              value={text}
              onChange={e => setText(e.target.value)}
              placeholder="Write a comment…"
              required
              style={{ flex: 1 }}
            />
            <button type="submit" className="btn-primary btn-sm">Post</button>
          </form>
          {err && <p style={{ color: C.danger, fontSize: 12, marginTop: 4 }}>{err}</p>}
        </div>
      )}
    </div>
  );
}

function Posts() {
  const [posts, setPosts]     = useState([]);
  const [content, setContent] = useState('');
  const [err, setErr]         = useState('');
  const [postErr, setPostErr] = useState('');
  const [loading, setLoading] = useState(false);

  const load = useCallback(async () => {
    try {
      const data = await gql('{ posts{ id content createdAt comments{id content createdAt author{username bio}} } }');
      setPosts(data.posts);
    } catch (e) { setErr(e.message); }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handlePost(e) {
    e.preventDefault();
    setPostErr(''); setLoading(true);
    try {
      await gql('mutation($c:String!){ createPost(content:$c){ id } }', { c: content });
      setContent('');
      load();
    } catch (e) { setPostErr(e.message); }
    finally { setLoading(false); }
  }

  return (
    <PageLayout>
      {/* Compose box */}
      <Card>
        <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start' }}>
          <div style={{
            width: 38, height: 38, borderRadius: '50%',
            background: `${C.accent}22`, border: `2px solid ${C.accent}44`,
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            color: C.accent, fontSize: 16, flexShrink: 0,
          }}>✎</div>
          <form onSubmit={handlePost} style={{ flex: 1 }}>
            <textarea
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="What's on your mind?"
              required
              style={{ marginBottom: 10 }}
            />
            {postErr && (
              <p style={{ color: C.danger, fontSize: 12, marginBottom: 8 }}>{postErr}</p>
            )}
            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <button type="submit" className="btn-primary btn-sm" disabled={loading}>
                {loading ? '…' : 'Publish'}
              </button>
            </div>
          </form>
        </div>
      </Card>

      {err && <p style={{ color: C.danger, fontSize: 13, marginBottom: 12 }}>{err}</p>}

      {posts.length === 0 && (
        <div style={{ textAlign: 'center', padding: '40px 0', color: C.text3 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>📭</div>
          <p>No posts yet. Be the first!</p>
        </div>
      )}

      {posts.map(post => (
        <Card key={post.id}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
            <div style={{
              width: 38, height: 38, borderRadius: '50%',
              background: C.bg3, border: `1px solid ${C.border}`,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              color: C.text3, fontSize: 18,
            }}>
              👤
            </div>
            <div>
              <div style={{ fontWeight: 600, fontSize: 13, color: C.text2 }}>
                Anonymous
              </div>
              <div style={{ fontSize: 11, color: C.text3, fontFamily: 'var(--mono)' }}>
                {timeAgo(post.createdAt)}
              </div>
            </div>
          </div>

          <p style={{ fontSize: 14, color: C.text, lineHeight: 1.6, marginBottom: 4 }}>
            {post.content}
          </p>

          <CommentSection postId={post.id} initialComments={post.comments} />
        </Card>
      ))}
    </PageLayout>
  );
}

// ── Messages ──────────────────────────────────────────────────────────────────

function Messages({ currentUser, initialRecipient }) {
  const [inbox, setInbox]         = useState([]);
  const [recipient, setRecipient] = useState(initialRecipient || '');
  const [content, setContent]     = useState('');
  const [err, setErr]             = useState('');
  const [sendErr, setSendErr]     = useState('');
  const [sent, setSent]           = useState(false);
  const [tab, setTab]             = useState('inbox');

  const loadInbox = useCallback(async () => {
    try {
      const data = await gql('{ inbox{ id content createdAt sender{username} recipient{username} } }');
      setInbox(data.inbox);
    } catch (e) { setErr(e.message); }
  }, []);

  useEffect(() => { loadInbox(); }, [loadInbox]);

  async function handleSend(e) {
    e.preventDefault();
    setSendErr(''); setSent(false);
    try {
      await gql(
        'mutation($r:String!,$c:String!){ sendMessage(recipientUsername:$r,content:$c){ id } }',
        { r: recipient, c: content }
      );
      setContent('');
      setSent(true);
      setTab('inbox');
      setTimeout(() => setSent(false), 3000);
      loadInbox();
    } catch (e) { setSendErr(e.message); }
  }

  const received  = inbox.filter(m => m.recipient.username === currentUser.username);
  const sent_msgs = inbox.filter(m => m.sender.username   === currentUser.username);

  const tabStyle = (active) => ({
    padding: '7px 18px', borderRadius: '6px 6px 0 0', fontSize: 13, fontWeight: 500,
    background: active ? C.bg2 : 'transparent',
    color: active ? C.accent : C.text2,
    border: active ? `1px solid ${C.border}` : '1px solid transparent',
    borderBottom: active ? `1px solid ${C.bg2}` : '1px solid transparent',
    marginBottom: -1,
  });

  return (
    <PageLayout>
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 4 }}>
          Messages
        </h2>
        <p style={{ color: C.text3, fontSize: 13 }}>
          Direct messages with other users on NexusNet.
        </p>
      </div>

      {/* Compose card */}
      <Card>
        <div style={{
          display: 'flex', alignItems: 'center', gap: 8, marginBottom: 16,
          paddingBottom: 12, borderBottom: `1px solid ${C.border}`,
        }}>
          <span style={{ fontSize: 16 }}>✉</span>
          <span style={{ fontWeight: 600, fontSize: 14, color: C.text }}>New Message</span>
        </div>
        <form onSubmit={handleSend}>
          <label style={{ display: 'block', fontSize: 12, color: C.text2, marginBottom: 5, fontWeight: 500 }}>
            Recipient
          </label>
          <input
            value={recipient}
            onChange={e => setRecipient(e.target.value)}
            placeholder="Enter username…"
            required
            style={{ marginBottom: 12 }}
          />
          <label style={{ display: 'block', fontSize: 12, color: C.text2, marginBottom: 5, fontWeight: 500 }}>
            Message
          </label>
          <textarea
            value={content}
            onChange={e => setContent(e.target.value)}
            placeholder="Write your message…"
            required
            style={{ marginBottom: 10 }}
          />
          {sendErr && <p style={{ color: C.danger, fontSize: 12, marginBottom: 8 }}>{sendErr}</p>}
          {sent && (
            <div style={{
              background: `${C.accent}15`, border: `1px solid ${C.accent}44`,
              borderRadius: 6, padding: '8px 12px', marginBottom: 10,
              color: C.accent, fontSize: 13,
            }}>
              ✓ Message sent
            </div>
          )}
          <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <button type="submit" className="btn-primary btn-sm">Send ↗</button>
          </div>
        </form>
      </Card>

      {err && <p style={{ color: C.danger, fontSize: 13, marginBottom: 12 }}>{err}</p>}

      {/* Inbox / Sent tabs */}
      <div style={{ marginBottom: 0, display: 'flex', borderBottom: `1px solid ${C.border}` }}>
        <button style={tabStyle(tab === 'inbox')}   onClick={() => setTab('inbox')}>
          Inbox <Badge color={C.accent2}>{received.length}</Badge>
        </button>
        <button style={tabStyle(tab === 'sent')}    onClick={() => setTab('sent')}>
          Sent <Badge color={C.text3}>{sent_msgs.length}</Badge>
        </button>
      </div>

      <div style={{ marginTop: 14 }}>
        {tab === 'inbox' && (
          received.length === 0
            ? <p style={{ color: C.text3, fontSize: 13, padding: '20px 0', textAlign: 'center' }}>
                No messages received yet.
              </p>
            : received.map(m => (
              <Card key={m.id}>
                <div style={{ display: 'flex', gap: 12 }}>
                  <Avatar name={m.sender.username} size={38} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: 13, color: C.accent2 }}>
                        {m.sender.username}
                      </span>
                      <span style={{ fontSize: 11, color: C.text3, fontFamily: 'var(--mono)' }}>
                        {timeAgo(m.createdAt)}
                      </span>
                    </div>
                    <p style={{ fontSize: 13, color: C.text, lineHeight: 1.5 }}>{m.content}</p>
                  </div>
                </div>
              </Card>
            ))
        )}

        {tab === 'sent' && (
          sent_msgs.length === 0
            ? <p style={{ color: C.text3, fontSize: 13, padding: '20px 0', textAlign: 'center' }}>
                No messages sent yet.
              </p>
            : sent_msgs.map(m => (
              <Card key={m.id} style={{ background: C.bg3 }}>
                <div style={{ display: 'flex', gap: 12 }}>
                  <Avatar name={m.recipient.username} size={38} />
                  <div style={{ flex: 1 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                      <span style={{ fontWeight: 600, fontSize: 13, color: C.text2 }}>
                        → <span style={{ color: C.text }}>{m.recipient.username}</span>
                      </span>
                      <span style={{ fontSize: 11, color: C.text3, fontFamily: 'var(--mono)' }}>
                        {timeAgo(m.createdAt)}
                      </span>
                    </div>
                    <p style={{ fontSize: 13, color: C.text, lineHeight: 1.5 }}>{m.content}</p>
                  </div>
                </div>
              </Card>
            ))
        )}
      </div>
    </PageLayout>
  );
}

// ── Users ─────────────────────────────────────────────────────────────────────

function Users({ onCompose }) {
  const [query, setQuery]       = useState('');
  const [results, setResults]   = useState([]);
  const [err, setErr]           = useState('');
  const [searched, setSearched] = useState(false);

  async function handleSearch(e) {
    e.preventDefault();
    setErr(''); setSearched(false);
    try {
      const data = await gql('query($q:String!){ searchUsers(query:$q){ id username bio } }', { q: query });
      setResults(data.searchUsers);
      setSearched(true);
    } catch (e) { setErr(e.message); }
  }

  return (
    <PageLayout>
      <div style={{ marginBottom: 20 }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, color: C.text, marginBottom: 4 }}>
          Find People
        </h2>
        <p style={{ color: C.text3, fontSize: 13 }}>
          Search for users on NexusNet.
        </p>
      </div>

      <Card>
        <form onSubmit={handleSearch} style={{ display: 'flex', gap: 10 }}>
          <input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search by username…"
            required
            style={{ flex: 1, marginBottom: 0 }}
          />
          <button type="submit" className="btn-primary" style={{ flexShrink: 0 }}>
            Search
          </button>
        </form>
      </Card>

      {err && <p style={{ color: C.danger, fontSize: 13, marginBottom: 12 }}>{err}</p>}

      {searched && results.length === 0 && (
        <div style={{ textAlign: 'center', padding: '40px 0', color: C.text3 }}>
          <div style={{ fontSize: 32, marginBottom: 8 }}>🔍</div>
          <p>No users found for "{query}"</p>
        </div>
      )}

      {results.map(u => (
        <Card key={u.id}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
            <Avatar name={u.username} size={46} />
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700, fontSize: 15, color: C.text, marginBottom: 2 }}>
                {u.username}
              </div>
              <div style={{ fontSize: 12, color: C.text3 }}>
                {u.bio || <em style={{ color: C.text3 }}>No bio</em>}
              </div>
            </div>
            <button
              className="btn-secondary btn-sm"
              onClick={() => onCompose(u.username)}
              style={{ flexShrink: 0 }}
            >
              ✉ Message
            </button>
          </div>
        </Card>
      ))}
    </PageLayout>
  );
}

// ── Root ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [user, setUser]           = useState(null);
  const [view, setView]           = useState('posts');
  const [composeTo, setComposeTo] = useState('');

  useEffect(() => {
    const token  = localStorage.getItem('token');
    const stored = localStorage.getItem('user');
    if (token && stored) {
      try { setUser(JSON.parse(stored)); } catch { /* ignore */ }
    }
  }, []);

  function handleAuth(token, u) {
    localStorage.setItem('token', token);
    localStorage.setItem('user', JSON.stringify(u));
    setUser(u);
    setView('posts');
  }

  function handleLogout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    setUser(null);
    setView('posts');
  }

  async function handlePurge() {
    if (!confirm('Reset the challenge database? This cannot be undone.')) return;
    try {
      await gql('mutation { purgeDatabase }');
      alert('Database reset. You have been logged out.');
      handleLogout();
    } catch (e) { alert(e.message); }
  }

  function handleCompose(username) {
    setComposeTo(username);
    setView('messages');
  }

  if (!user) return <AuthForm onAuth={handleAuth} />;

  return (
    <div style={{ minHeight: '100vh', background: C.bg }}>
      <Topbar
        user={user}
        view={view}
        onView={setView}
        onLogout={handleLogout}
        onPurge={handlePurge}
      />

      {view === 'posts'    && <Posts />}
      {view === 'messages' && <Messages currentUser={user} initialRecipient={composeTo} />}
      {view === 'users'    && <Users    onCompose={handleCompose} />}
    </div>
  );
}
