// GraphQL API client
// Relative path — proxied to the backend by nginx in production,
// and proxied by Vite dev server in development.
const GRAPHQL_ENDPOINT = '/graphql';

export async function gql(query, variables = {}) {
  const token = localStorage.getItem('token');
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const res = await fetch(GRAPHQL_ENDPOINT, {
    method: 'POST',
    headers,
    body: JSON.stringify({ query, variables }),
  });

  const json = await res.json();
  if (json.errors) throw new Error(json.errors[0].message);
  return json.data;
}
