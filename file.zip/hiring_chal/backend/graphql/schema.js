const { buildSchema } = require('graphql');
const { getDb, hashPassword, verifyPassword, purgeDb } = require('../database/init');
const { signToken } = require('../auth/jwt');

const typeDefs = `
  # Public user view — secret is intentionally included in the type
  # so introspection reveals it exists, but resolvers control what gets returned
  type User {
    id: ID!
    username: String!
    bio: String!
    secret: String!
  }

  # Reduced user view returned from safe nested resolvers (comments, messages)
  type PublicUser {
    id: ID!
    username: String!
    bio: String!
  }

  type Post {
    id: ID!
    content: String!
    createdAt: String!
    author: User!
    comments: [Comment!]!
  }

  type Comment {
    id: ID!
    content: String!
    createdAt: String!
    author: PublicUser!
  }

  type Message {
    id: ID!
    content: String!
    createdAt: String!
    sender: PublicUser!
    recipient: PublicUser!
  }

  type AuthPayload {
    token: String!
    user: PublicUser!
  }

  type Query {
    # Returns all posts — author resolver is VULNERABLE (returns full User including secret)
    posts: [Post!]!

    # Returns a single post by id
    post(id: ID!): Post!

    # Inbox: only returns messages where you are sender or recipient
    inbox: [Message!]!

    # Search users by username prefix — returns PublicUser only (no secret)
    searchUsers(query: String!): [PublicUser!]!
  }

  type Mutation {
    register(username: String!, password: String!): AuthPayload!
    login(username: String!, password: String!): AuthPayload!

    createPost(content: String!): Post!
    deletePost(id: ID!): String!

    addComment(postId: ID!, content: String!): Comment!

    sendMessage(recipientUsername: String!, content: String!): Message!

    purgeDatabase: String!
  }
`;

const schema = buildSchema(typeDefs);

// ── Helpers ───────────────────────────────────────────────────────────────────

function requireAuth(context) {
  if (!context.user) throw new Error('Unauthorized');
}

// Returns a PublicUser row (no secret) — used in safe nested resolvers
function publicUser(db, userId) {
  return db.prepare('SELECT id, username, bio FROM users WHERE id = ?').get(userId);
}

// Returns a full User row — used ONLY in the vulnerable posts->author resolver
function fullUser(db, userId) {
  return db.prepare('SELECT id, username, bio, secret FROM users WHERE id = ?').get(userId);
}

function resolveComments(postId) {
  return () => {
    const db = getDb();
    const comments = db.prepare(
      'SELECT * FROM comments WHERE post_id = ? ORDER BY created_at ASC'
    ).all(postId);
    db.close();

    return comments.map(c => ({
      id: c.id,
      content: c.content,
      createdAt: c.created_at,
      // SAFE: comment authors go through publicUser — no secret exposed
      author: () => {
        const db2 = getDb();
        const u = publicUser(db2, c.user_id);
        db2.close();
        return u;
      }
    }));
  };
}

// ── Resolvers ─────────────────────────────────────────────────────────────────

const rootValue = {

  // ── Queries ────────────────────────────────────────────────────────────────

  posts(_, context) {
    requireAuth(context);
    const db = getDb();
    const posts = db.prepare('SELECT * FROM posts ORDER BY created_at DESC').all();
    db.close();

    return posts.map(post => ({
      id: post.id,
      content: post.content,
      createdAt: post.created_at,
      comments: resolveComments(post.id),
      // !! VULNERABLE: returns full User row including secret — no access control !!
      // Any authenticated user can extract any author's secret via:
      //   posts { author { secret } }
      author: () => {
        const db2 = getDb();
        const user = fullUser(db2, post.user_id);
        db2.close();
        return user;
      }
    }));
  },

  post({ id }, context) {
    requireAuth(context);
    const db = getDb();
    const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(id);
    db.close();
    if (!post) throw new Error('Post not found');

    return {
      id: post.id,
      content: post.content,
      createdAt: post.created_at,
      comments: resolveComments(post.id),
      // VULNERABLE: same as posts resolver
      author: () => {
        const db2 = getDb();
        const user = fullUser(db2, post.user_id);
        db2.close();
        return user;
      }
    };
  },

  inbox(_, context) {
    requireAuth(context);
    const db = getDb();
    // SAFE: strict check — only messages where current user is sender or recipient
    const msgs = db.prepare(`
      SELECT * FROM messages
      WHERE sender_id = ? OR recipient_id = ?
      ORDER BY created_at DESC
    `).all(context.user.id, context.user.id);
    db.close();

    return msgs.map(m => ({
      id: m.id,
      content: m.content,
      createdAt: m.created_at,
      // SAFE: both sides of a message use PublicUser — no secret
      sender: () => {
        const db2 = getDb();
        const u = publicUser(db2, m.sender_id);
        db2.close();
        return u;
      },
      recipient: () => {
        const db2 = getDb();
        const u = publicUser(db2, m.recipient_id);
        db2.close();
        return u;
      }
    }));
  },

  searchUsers({ query }, context) {
    requireAuth(context);
    if (!query || query.trim().length < 1) throw new Error('Search query too short');
    const db = getDb();
    // SAFE: returns PublicUser only — no secret field
    const users = db.prepare(
      'SELECT id, username, bio FROM users WHERE username LIKE ? LIMIT 20'
    ).all(`${query.trim()}%`);
    db.close();
    return users;
  },

  // ── Mutations ──────────────────────────────────────────────────────────────

  register({ username, password }) {
    if (!username || !password) throw new Error('Username and password required');
    if (username.length < 3) throw new Error('Username must be at least 3 characters');
    if (password.length < 4) throw new Error('Password must be at least 4 characters');

    const db = getDb();
    const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
    if (existing) { db.close(); throw new Error('Username already taken'); }

    const hashed = hashPassword(password);
    const result = db.prepare(
      'INSERT INTO users (username, password, secret, bio) VALUES (?, ?, ?, ?)'
    ).run(username, hashed, '', '');
    db.close();

    const token = signToken({ id: result.lastInsertRowid, username });
    return { token, user: { id: result.lastInsertRowid, username, bio: '' } };
  },

  login({ username, password }) {
    if (!username || !password) throw new Error('Username and password required');

    const db = getDb();
    const user = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
    db.close();

    if (!user || !verifyPassword(password, user.password)) {
      throw new Error('Invalid credentials');
    }

    const token = signToken({ id: user.id, username: user.username });
    return { token, user: { id: user.id, username: user.username, bio: user.bio } };
  },

  createPost({ content }, context) {
    requireAuth(context);
    if (!content || !content.trim()) throw new Error('Content cannot be empty');
    if (content.length > 500) throw new Error('Post too long (max 500 characters)');

    const db = getDb();
    const result = db.prepare(
      'INSERT INTO posts (user_id, content) VALUES (?, ?)'
    ).run(context.user.id, content.trim());

    const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(result.lastInsertRowid);
    const author = db.prepare('SELECT id, username, bio, secret FROM users WHERE id = ?').get(context.user.id);
    db.close();

    return {
      id: post.id,
      content: post.content,
      createdAt: post.created_at,
      comments: resolveComments(post.id),
      author
    };
  },

  deletePost({ id }, context) {
    requireAuth(context);
    const db = getDb();
    const post = db.prepare('SELECT user_id FROM posts WHERE id = ?').get(id);
    if (!post) { db.close(); throw new Error('Post not found'); }
    // SAFE: only the author can delete their own post
    if (post.user_id !== context.user.id) { db.close(); throw new Error('Forbidden'); }
    db.prepare('DELETE FROM comments WHERE post_id = ?').run(id);
    db.prepare('DELETE FROM posts WHERE id = ?').run(id);
    db.close();
    return 'Post deleted';
  },

  addComment({ postId, content }, context) {
    requireAuth(context);
    if (!content || !content.trim()) throw new Error('Comment cannot be empty');
    if (content.length > 300) throw new Error('Comment too long (max 300 characters)');

    const db = getDb();
    const post = db.prepare('SELECT id FROM posts WHERE id = ?').get(postId);
    if (!post) { db.close(); throw new Error('Post not found'); }

    const result = db.prepare(
      'INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)'
    ).run(postId, context.user.id, content.trim());

    const comment = db.prepare('SELECT * FROM comments WHERE id = ?').get(result.lastInsertRowid);
    // SAFE: comment author uses publicUser
    const author = publicUser(db, context.user.id);
    db.close();

    return {
      id: comment.id,
      content: comment.content,
      createdAt: comment.created_at,
      author
    };
  },

  sendMessage({ recipientUsername, content }, context) {
    requireAuth(context);
    if (!content || !content.trim()) throw new Error('Message cannot be empty');
    if (content.length > 1000) throw new Error('Message too long (max 1000 characters)');
    if (recipientUsername === context.user.username) throw new Error('Cannot message yourself');

    const db = getDb();
    const recipient = db.prepare('SELECT id, username, bio FROM users WHERE username = ?').get(recipientUsername);
    if (!recipient) { db.close(); throw new Error('User not found'); }

    const result = db.prepare(
      'INSERT INTO messages (sender_id, recipient_id, content) VALUES (?, ?, ?)'
    ).run(context.user.id, recipient.id, content.trim());

    const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(result.lastInsertRowid);
    const sender = publicUser(db, context.user.id);
    db.close();

    return {
      id: msg.id,
      content: msg.content,
      createdAt: msg.created_at,
      // SAFE: both sides PublicUser
      sender,
      recipient
    };
  },

  purgeDatabase() {
    purgeDb();
    return 'Database purged and re-seeded successfully';
  }
};

module.exports = { schema, rootValue };
