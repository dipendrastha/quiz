const Database = require('better-sqlite3');
const crypto = require('crypto');
const path = require('path');

const DB_PATH = path.join(__dirname, 'challenge.db');

function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  const [salt, hash] = stored.split(':');
  const verify = crypto.pbkdf2Sync(password, salt, 10000, 64, 'sha512').toString('hex');
  return verify === hash;
}

function getDb() {
  return new Database(DB_PATH);
}

function initDb() {
  const db = getDb();

  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      secret TEXT NOT NULL DEFAULT '',
      bio TEXT NOT NULL DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS posts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS comments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      post_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (post_id) REFERENCES posts(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    );

    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      recipient_id INTEGER NOT NULL,
      content TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')),
      FOREIGN KEY (sender_id) REFERENCES users(id),
      FOREIGN KEY (recipient_id) REFERENCES users(id)
    );
  `);

  // Seed the flag user if not already present
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get('admin');
  if (!existing) {
    const hashed = hashPassword('sup3rs3cr3tpassword');
    db.prepare(
      'INSERT INTO users (username, password, secret, bio) VALUES (?, ?, ?, ?)'
    ).run('admin', hashed, 'LFCTF{gr4phQL_n3st3d_qu3r13s_4r3_fun}', 'Platform administrator.');

    const adminId = db.prepare('SELECT id FROM users WHERE username = ?').get('admin').id;

    // Seed posts
    const post1 = db.prepare('INSERT INTO posts (user_id, content) VALUES (?, ?)').run(
      adminId, 'Welcome to this platform! Feel free to post and comment.'
    );
    const post2 = db.prepare('INSERT INTO posts (user_id, content) VALUES (?, ?)').run(
      adminId, 'Remember: keep your secrets safe.'
    );

    // Seed a couple of comments on the posts
    db.prepare('INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)').run(
      post1.lastInsertRowid, adminId, 'Glad to have you here!'
    );
    db.prepare('INSERT INTO comments (post_id, user_id, content) VALUES (?, ?, ?)').run(
      post2.lastInsertRowid, adminId, 'Security is everyone\'s responsibility.'
    );
  }

  db.close();
  console.log('Database initialised at', DB_PATH);
}

function purgeDb() {
  const db = getDb();
  db.exec('DELETE FROM messages; DELETE FROM comments; DELETE FROM posts; DELETE FROM users;');
  db.close();
  // Re-seed
  initDb();
  console.log('Database purged and re-seeded.');
}

module.exports = { getDb, initDb, purgeDb, hashPassword, verifyPassword };
