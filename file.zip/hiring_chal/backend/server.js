const http = require('http');
const { graphql } = require('graphql');
const { schema, rootValue } = require('./graphql/schema');
const { extractUser } = require('./auth/jwt');
const { initDb } = require('./database/init');

const PORT = process.env.PORT || 4000;

// Initialise DB on startup
initDb();

function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Methods': 'POST, OPTIONS'
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        resolve(JSON.parse(body));
      } catch {
        reject(new Error('Invalid JSON'));
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization',
      'Access-Control-Allow-Methods': 'POST, OPTIONS'
    });
    res.end();
    return;
  }

  // Only handle POST /graphql
  if (req.method !== 'POST' || req.url !== '/graphql') {
    sendJson(res, 404, { errors: [{ message: 'Not found' }] });
    return;
  }

  let body;
  try {
    body = await readBody(req);
  } catch {
    sendJson(res, 400, { errors: [{ message: 'Invalid JSON body' }] });
    return;
  }

  const { query, variables, operationName } = body;
  if (!query) {
    sendJson(res, 400, { errors: [{ message: 'Missing query' }] });
    return;
  }

  // Extract authenticated user from JWT — passed into GraphQL context
  const user = extractUser(req);

  try {
    const result = await graphql({
      schema,
      source: query,
      rootValue,
      contextValue: { user },
      variableValues: variables,
      operationName
    });
    sendJson(res, 200, result);
  } catch (err) {
    sendJson(res, 500, { errors: [{ message: err.message }] });
  }
});

server.listen(PORT, () => {
  console.log(`GraphQL server running at http://localhost:${PORT}/graphql`);
});
